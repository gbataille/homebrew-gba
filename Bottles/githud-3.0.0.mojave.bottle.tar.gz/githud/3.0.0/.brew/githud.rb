require "language/haskell"

class Githud < Formula
  include Language::Haskell::Cabal

  version_number = "3.0.0"

  desc "Clean git HUD for your prompt"
  homepage "https://github.com/gbataille/gitHUD"
  url "https://hackage.haskell.org/package/githud-#{version_number}/githud-#{version_number}.tar.gz"
  sha256 "b98b2ea9f85f4d16b70290da1d2021a1821cc9b03bbd2b16b7da850e606927ff"

  # bottle do
  #   root_url "https://github.com/gbataille/homebrew-gba/raw/master/Bottles"
  #   sha256 "5b235e36c1a1cbf26bb131aa3f1dace2943e335e7bb6af9529ee30b4b8f788a9" => :high_sierra
  #   sha256 "33113e6b33222c625950fe5412d11c28d1336eddf37acd4ec9cb35968b024878" => :mojave
  # end

  depends_on "ghc" => :build
  depends_on "cabal-install" => :build

  def install
    install_cabal_package
  end

  test do
    system "#{bin}/githud", "zsh"
  end
end
