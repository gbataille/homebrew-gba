module Main where

import GitHUD

main :: IO ()
main = githud
