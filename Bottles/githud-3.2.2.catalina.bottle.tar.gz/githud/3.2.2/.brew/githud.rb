require "language/haskell"

class Githud < Formula
  version_number = "3.2.2"

  desc "Clean git HUD for your prompt"
  homepage "https://github.com/gbataille/gitHUD"
  url "https://hackage.haskell.org/package/githud-#{version_number}/githud-#{version_number}.tar.gz"
  sha256 "e32942ceae27108dbab283cd790d42575512ae0ad1b317d080cdba8e0d0fe2a7"

  depends_on "ghc@8.8" => :build
  depends_on "cabal-install" => :build

  def install
    system "cabal", "v2-update"
    system "cabal", "v2-install", *std_cabal_v2_args
  end

  test do
    system "#{bin}/githud", "zsh"
  end
end
