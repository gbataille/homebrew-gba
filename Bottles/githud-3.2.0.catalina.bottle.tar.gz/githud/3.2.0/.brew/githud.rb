require "language/haskell"

class Githud < Formula
  include Language::Haskell::Cabal

  version_number = "3.2.0"

  desc "Clean git HUD for your prompt"
  homepage "https://github.com/gbataille/gitHUD"
  url "https://hackage.haskell.org/package/githud-#{version_number}/githud-#{version_number}.tar.gz"
  sha256 "0a354f9731392ef1867d8c7fb0b1ae2351004680a673e09ad1baa02d140c028b"

  # bottle do
  #   root_url "https://github.com/gbataille/homebrew-gba/raw/master/Bottles"
  #   sha256 "f748bec8477701ee58cdd1146a52a41d12369f58f682a4c0bccba30e61ae27a5" => :mojave
  # end

  depends_on "ghc@8.6" => :build
  depends_on "cabal-install" => :build

  def install
    install_cabal_package
  end

  test do
    system "#{bin}/githud", "zsh"
  end
end
